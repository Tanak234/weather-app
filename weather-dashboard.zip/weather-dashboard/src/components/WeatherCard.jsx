import React from 'react';


const WeatherCard = ({ weather }) => {
    if (!weather) {
        return <div className="weather-card">Loading...</div>;
    }

    const { temperature, condition, icon, humidity, windSpeed } = weather;

    return (
        <div className="weather-card">
            <h2>{condition}</h2>
            <img src={icon} alt={condition} />
            <p>Temperature: {temperature}°C</p>
            <p>Humidity: {humidity}%</p>
            <p>Wind Speed: {windSpeed} m/s</p>
        </div>
    );
};

export default WeatherCard;